
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class Shimla extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Shimla(String n,String opt){
        this.name = n;
        this.opt = opt;
        Container c = this.getContentPane();
        getContentPane().setLayout(null);
        ba = new JButton("Back");
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        c.add(ba);
        
        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/am.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblHelloWorld = new JLabel("Shimla");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblkanheriCavesKanheri = new JLabel("<html>2.Himachal State Museum<br>\r\n<br>\r\nIt includes works of art created during the period stretching from about 1860 to the 20s, and denotes the styles and philosophy of art created in this era.'Art & artifacts such as ancient tools, dolls, coins & traditional garments in a Victorian mansion.\r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 217, 425, 110);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>3.Gorton castle<br>\r\n<br>\r\nGorton Castle is a heritage monument located in Shimla which is over a century old and was built during the Colonial era. Today, the castle is used as the office of the Accountant General of Himachal Pradesh. It is a perfect illustration of the rich history and heritage of India during the colonial era. The monument is built according to the Neo-Gothic type of architecture and exudes the vibe of a fairy tale with its characteristic features. The Gorton Castle is located on a hilltop and is surrounded by tall lush green Deodar trees. The scenic beauty of the location makes it look incredibly majestic.</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 338, 425, 149);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>4.Chadwick Falls<br>\r\n<br>\r\nAlso known as one of the most popular sightseeing places in Shimla, Chadwick Falls has always been a delightful experience for tourists. It is an amazing place to hang out with your friends and offers a great hiking trail that lets you explore its quietness, away from the hustle and bustle of city life. The soothing environment and the mesmerizing views enchant tourists from all around the world and make one to overlook the surrounding beauty.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 498, 425, 154);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/sm.jpg");
        label.setIcon(img2);
        label.setBounds(150, 255, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/castle.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 390, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/falls.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 543, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>Army heritage museum<br>\r\n<br>\r\nThe Museum Narrates Story of warfare and how on many instances Indian forces have proved their excellence in it. It displays weapons, tools, uniforms. It celebrates brave heroes. The place make you feel amazed as well as proud. It does have beautiful garden landscape, a glass house and children play area.\r\n\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 138);
        getContentPane().add(lblNewLabel_1);
        

        ba.addActionListener(this);

    }


}

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



class Goa extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Goa(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton("Back");
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        getContentPane().add(ba);
        
        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/velha.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblHelloWorld = new JLabel("Goa");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblkanheriCavesKanheri = new JLabel("<html>Panaji<br>\r\n<br>\r\nPanaji, also known as Panjim, is the state capital of Goa, in southwest India. Located on the banks of the Mandovi River, the city has cobblestone streets lined with colorful villas an buildings from the Portuguese colonial era. Palm-fringed Miramar Beach sits at the confluence of the river and the Arabian Sea. Set on a hill overlooking the city is the baroque Our Lady of Immaculate Conception Church, built in 1619.\r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 217, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Palolem Beach<br>\r\n<br>\r\nUncrowded stretch of white sand with calm waters, a restaurant and silent disco music parties. Palolem Beach has a tropical climate, with warm temperatures all year. A popular time to visit is Dec\u2013Feb, when daytime temperatures are high and nights are relatively cool. The monsoon season (Jun\u2013Sep) brings heavy rain. Every year, the Goa Carnival (Feb/Mar) features colorful parades, live music and dancing.</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 338, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>Calangute<br>\r\n<br>\r\n\r\nCalangute is a town in the western Indian state of Goa. Standing on the shores of the Arabian Sea, it\u2019s home to long, sandy Calangute Beach, lined with restaurants and bars. Farther north, Baga Beach is a popular spot for water sports. To the south, the sturdy walls of Aguada Fort, built in the early 1600s under Portuguese colonial rule, surround a 19th-century lighthouse.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 498, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/panaji.jpg");
        label.setIcon(img2);
        label.setBounds(150, 255, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/beach.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 390, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/calangute.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 543, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>nGoa Velha<br>\r\n<br>\r\nThis was one of the many residences of Mahatma Gandhi who lived at Sabarmati and Sevagram when he was not travelling across India or in prison. He lived in Sabarmati or Wardha for a total of twelve years with his wife Kasturba Gandhi and followers, including Vinoba Bhave. It was from his base here that Gandhi led the Dandi march also known as the Salt Satyagraha on 12 March 1930.\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);


        
        ba.addActionListener(this);

    }


}
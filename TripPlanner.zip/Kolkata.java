
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class Kolkata extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Kolkata(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton("Back");
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        getContentPane().add(ba);
        
        JLabel lblHelloWorld = new JLabel("Kolkata");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/victoria.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblkanheriCavesKanheri = new JLabel("<html>Howrah Bridge<br>\r\n<br>\r\nHowrah Bridge is a bridge with a suspended span over the Hooghly River in West Bengal, India. Commissioned in 1943, the bridge was originally named the New Howrah Bridge, because it replaced a pontoon bridge at the same location linking the two cities of Howrah and Kolkata. On 14 June 1965 it was renamed Rabindra Setu after the great Bengali poet Rabindranath Tagore, who was the first Indian and Asian Nobel laureate. It is still popularly known as the Howrah Bridge.\r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 217, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>\r\n\nDakshineswar Kali Temple<br>\r\n<br>\r\nDakshineswar Kali Temple is a Hindu navaratna temple located at Dakshineswar. Situated on the eastern bank of the Hooghly River, the presiding deity of the temple is Bhavatarini, an aspect of Kali, meaning, 'She who liberates Her devotees from the ocean of existence i.e. Sa\u1E43s\u0101ra'. The temple was built in 1855 by Rani Rashmoni, a philanthropist and a devotee of Kali. The temple is famous for its association with Ramakrishna, a mystic of 19th Century Bengal.</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 370, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>The Indian Museum<br>\r\n<br>\r\nIt is also referred to as the Imperial Museum at Calcutta in colonial-era texts, is the ninth oldest museum of the world, oldest museum in India and the largest museum in India. It has rare collections of antiques, armour and ornaments, fossils, skeletons, mummies and Mughal paintings. It was founded by the Asiatic Society of Bengal in Kolkata, India, in 1814.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 520, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/bridge.jpg");
        label.setIcon(img2);
        label.setBounds(150, 255, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/kali.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 420, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/museum.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 570, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>The Victoria Memorial<br>\r\n<br>\r\nThe Victoria Memorial is a large marble building in Kolkata, West Bengal, India, which was built between 1906 and 1921. It is dedicated to the memory of Queen Victoria, then Empress of India, and is now a museum and tourist destination under the auspices of the Ministry of Culture. The memorial lies on the Maidan by the bank of the Hooghly River, near Jawaharlal Nehru Road.\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);


        
        ba.addActionListener(this);

    }


}
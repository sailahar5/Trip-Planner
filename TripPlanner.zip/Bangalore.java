
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class Bangalore extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Bangalore(String n,String opt){
        this.name = n;
        this.opt =opt;
        Container c = this.getContentPane();
        getContentPane().setLayout(null);
        ba = new JButton();
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        
        c.add(ba);
        
        JLabel lblHelloWorld = new JLabel("Bangalore");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/gardens.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblkanheriCavesKanheri = new JLabel("<html>Cubbon Park<br>\r\n<br>\r\nIt is officially called Sri Chamarajendra Park is a landmark 'lung' area of Bengaluru city, located within the heart of the city in the Central Administrative Area. Originally created in 1870, when Major General Richard Sankey was the then British Chief Engineer of Mysore state, it covered an area of 100 acres and subsequent expansion has taken place and the area reported now is about 300 acres. \r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 217, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Bangalore Palace<br>\r\n<br>\r\nBangalore Palace is a royal palace located in Bangalore, Karnataka, India, in an area that was owned by Rev. J. Garrett, the first principal of the Central High School in Bangalore, now famous as Central College. The commencement of the construction of the palace is attributed to him.</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 338, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>Bannerghatta National Park<br>\r\n<br>\r\nBannerghatta National Park was founded in 1970 and declared as a national park in 1974. It is a popular tourist destination with a zoo. There are ancient temples in the park for worship and it is a destination for trekking and hiking.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 498, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/park.jpg");
        label.setIcon(img2);
        label.setBounds(150, 255, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/palace.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 390, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/np.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 543, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>Lalbagh Botanical Gardens<br>\r\n<br>\r\nLalbagh Botanical Gardens or Lalbagh is an old botanical garden in Bengaluru.It was managed under numerous British Superintendents before Indian Independence. It also served a social function as a park and recreational space.\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);


        
        ba.addActionListener(this);

    }


}
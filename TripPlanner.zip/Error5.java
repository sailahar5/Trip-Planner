// import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Error5 extends JFrame implements ActionListener{
    JButton ba;

    public void actionPerformed(ActionEvent ae){
        Enter e = new Enter();
        e.setSize(1000,700);
        e.setTitle("Login");
        e.setVisible(true);
        e.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        dispose();
    }
    Error5(){
    	getContentPane().setLayout(null);
    	
    	JLabel lblNewLabel = new JLabel("Please enter a name and set a password");
    	lblNewLabel.setBounds(50, 36, 404, 14);
    	getContentPane().add(lblNewLabel);
    	
    	JButton ba = new JButton("OK");
    	ba.setBounds(167, 91, 80, 23);
        getContentPane().add(ba);
        
        ba.addActionListener(this);

    }
    

}
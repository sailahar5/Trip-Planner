
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class Chennai extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Chennai(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton();
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        
        getContentPane().add(ba);
        
        JLabel lblHelloWorld = new JLabel("Chennai");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/marina.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblkanheriCavesKanheri = new JLabel("<html>The Government Museum<br>\r\n<br>\r\nThe Madras Museum is a museum of human history and culture located in the Government Museum Complex in the neighbourhood of Egmore in Chennai, India. Started in 1851, it is the second oldest museum in India and is the tenth oldest Museum in the World. It is particularly rich in archaeological and numismatic collections. It has the largest collection of Roman antiquities outside Europe.\r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 217, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Fort St George<br>\r\n<br>\r\nFort St George is the first English fortress in India, founded in 1644 at the coastal city of Madras. The construction of the fort provided the impetus for further settlements and trading activity. The fort currently houses the Tamil Nadu legislative assembly and other official buildings.</html>\r\n");

        lblfortGeorgeFort.setBounds(324, 338, 425, 217);
        getContentPane().add(lblfortGeorgeFort);        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>San Thome Church<br>\r\n<br>\r\nSan Thome Church also known as St. Thomas Cathedral Basilica in the city of Chennai, India. It was built in the 16th century by Portuguese explorers, over the tomb of Saint Thomas, one of the twelve apostles of Jesus. In 1893, it was rebuilt as a church with the status of a cathedral by the British. The British version still stands today.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 498, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/gov.jpg");
        label.setIcon(img2);
        label.setBounds(150, 255, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/fort.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 390, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/san.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 543, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>Marina Beach<br>\r\n<br>\r\nIt is a natural urban beach in Chennai, Tamil Nadu, India, along the Bay of Bengal. The beach runs from near Fort St. George in the north to Foreshore Estate in the south, a distance of 6.0 km, making it the longest natural urban beach in the country. The Marina is primarily sandy, unlike the short, rocky formations that make up the Juhu Beach in Mumbai.Bathing and swimming at the Marina Beach are legally prohibited because of the dangers, as the undercurrent is very turbulent. \r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);

        ba.addActionListener(this);

    }


}
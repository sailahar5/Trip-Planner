import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class ticketpreview extends JFrame implements ActionListener{
	String name,firstname;
	String lastname;
	String date;
	String to,from,email,flight;
	int cost,no;
	JButton btnNewButton;
	JButton btnNewButton_1;
	private JTextField textField;//implements ActionListener
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;

	public void actionPerformed(ActionEvent ae){
			if(ae.getSource() == btnNewButton){
					flight1 fl = new flight1(name);
					fl.setSize(700,700);
					fl.setTitle("flight");
					fl.setVisible(true);
					dispose();
		}
			if(ae.getSource() == btnNewButton_1){
				Conclusion cs = new Conclusion(name);
				cs.setSize(700,700);
				cs.setVisible(true);
				cs.setTitle("Conclusion");
				cs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
				dispose();
		}
		}

	ticketpreview(String name,String firstname,String lastname,String date,String to,String from,String email,int no,String flight,int cost){
		this.name = name; 
		this.firstname = firstname;
		this.lastname = lastname;
		this.date = date;
		this.to = to;
		this.from = from;
		this.email = email;
		this.no = no;
		this.flight = flight;
		this.cost = cost;
		
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("              Ticket Preview");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(169, 40, 524, 37);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("First Name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 169, 83, 14);
		getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField.setEditable(false);
		textField.setBounds(140, 166, 155, 37);
		getContentPane().add(textField);
		textField.setColumns(10);

		textField.setText(firstname);
		
		JLabel lblNewLabel_2 = new JLabel("Last Name:\r\n");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 255, 83, 14);
		getContentPane().add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_1.setEditable(false);
		textField_1.setBounds(140, 244, 155, 37);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_1.setText(lastname);

		JLabel lblNewLabel_3 = new JLabel("Date:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(10, 340, 83, 14);
		getContentPane().add(lblNewLabel_3);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_2.setEditable(false);
		textField_2.setBounds(140, 329, 155, 37);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_2.setText(date);

		JSeparator separator = new JSeparator();
		separator.setBounds(261, 88, 1, 2);
		getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(272, 88, 242, 2);
		getContentPane().add(separator_1);
		
		JLabel lblNewLabel_4 = new JLabel("To:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(10, 424, 83, 14);
		getContentPane().add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_3.setEditable(false);
		textField_3.setBounds(140, 413, 155, 37);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_3.setText(to);

		JLabel lblNewLabel_5 = new JLabel("From:\r\n\r\n\r\n");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(10, 506, 83, 14);
		getContentPane().add(lblNewLabel_5);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_4.setEditable(false);
		textField_4.setBounds(140, 497, 155, 37);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		textField_4.setText(from);

		btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(45, 652, 89, 40);
		getContentPane().add(btnNewButton);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(375, 124, 1, 463);
		getContentPane().add(separator_2);
		
		JLabel lblNewLabel_6 = new JLabel("Email:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(425, 169, 49, 14);
		getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("No of people:\r\n");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(424, 249, 111, 26);
		getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Flight:");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8.setBounds(425, 340, 71, 26);
		getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Cost:\r\n\r\n");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_9.setBounds(425, 424, 49, 14);
		getContentPane().add(lblNewLabel_9);
		
		textField_5 = new JTextField();
		textField_5.setEditable(false);
		textField_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_5.setBounds(545, 169, 147, 37);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);
		textField_5.setText(email);

		
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_6.setBounds(545, 243, 147, 40);
		getContentPane().add(textField_6);
		textField_6.setColumns(10);
		textField_6.setText(""+(no));
		
		textField_7 = new JTextField();
		textField_7.setEditable(false);
		textField_7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_7.setBounds(546, 329, 147, 37);
		getContentPane().add(textField_7);
		textField_7.setColumns(10);
		textField_7.setText(flight);

		textField_8 = new JTextField();
		textField_8.setEditable(false);
		textField_8.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_8.setBounds(545, 413, 147, 37);
		getContentPane().add(textField_8);
		textField_8.setColumns(10);
		textField_8.setText(""+cost);

		btnNewButton_1 = new JButton("Get Coupon");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_1.setBounds(600, 654, 130, 36);
		getContentPane().add(btnNewButton_1);
		
		JLabel lblTotalCost = new JLabel("Total Cost:\r\n\r\n");
		lblTotalCost.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTotalCost.setBounds(425, 506, 89, 14);
		getContentPane().add(lblTotalCost);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_9.setEditable(false);
		textField_9.setColumns(10);
		textField_9.setBounds(546, 497, 147, 37);
		getContentPane().add(textField_9);
		textField_9.setText(""+(no*cost));

		btnNewButton.addActionListener(this);
		btnNewButton_1.addActionListener(this);
		
	}

}
	
	
	
import java.awt.*;
import java.awt.event.*;
import java.lang.Math;
import javax.swing.*;

class flightn extends JFrame implements ActionListener{
	String name;
	ButtonGroup bg;
	JButton ba;
	JButton con;
	String firstname;
	String lastname,email;
	JLabel date;
	JLabel head;
	int q;
	String fli;
	int cost;
	int ap1,ap2,ap3,ap4;
	int cr1,cr2,cr3,cr4;
	JRadioButton r1,r2,r3,r4;
	String to,from,dt,month,year,people;
	String c[] = {"4600","5000","3900","7000","6600","5500","4200","4200","6300","6500"};
	String a[][] = {{"Indigo 6E 241","Spicejet SG 413","Air India AI 0018"},
					{"Indigo 6E 458","Spicejet SG 487","Air India AI 0011"},
					{"Indigo 6E-152","Spicejet SG 252","Air India AI 0014"},
					{"Indigo 6E 82","Spicejet SG 140","Air India 9I 0873"}};

					public void actionPerformed(ActionEvent ae){
						if(ae.getSource() == ba){
							flight1 fl = new flight1(name);
							fl.setSize(700,700);
							fl.setTitle("flight");
							fl.setVisible(true);
							dispose();
							
						}
						if(ae.getSource() == con){
							if(r1.getModel().isSelected()){
								fli = a[0][ap1] ;
								cost = Integer.parseInt(c[cr1]);
							}
							if(r2.getModel().isSelected()){
								fli = a[1][ap2] ;
								cost = Integer.parseInt(c[cr2]);
							}
							if(r3.getModel().isSelected()){
								fli = a[2][ap3] ;
								cost = Integer.parseInt(c[cr3]);
							}
							if(r4.getModel().isSelected()){
								fli = a[3][ap4] ;
								cost = Integer.parseInt(c[cr4]);
							}
							ticketpreview tp = new ticketpreview(name,firstname,lastname,date.getText(),to,from,email,q,fli,cost);//
							tp.setSize(800,800);
							tp.setTitle("Flight Priview");
							tp.setVisible(true);
							tp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
							dispose();
						}
					}
						
    flightn(String n,String firstname,String lastname,String email,String to,String from,String dt,String month,String year,String p){
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.to = to;
		this.from = from;
		this.name = n;
		this.dt = dt;
		this.month = month;
		this.year = year;
		this.people = p;
		q = Integer.parseInt(p);

		getContentPane().setLayout(null);

			JLabel bga = new JLabel("");
			bga.setIcon(new ImageIcon("Images/gr1.jpg"));
			bga.setBounds(0,0,800,700);
			getContentPane().add(bga);

		ba = new JButton("Back");
    	ba.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
    	ba.setBounds(51, 574, 117, 42);
    	bga.add(ba);
    	
    	con = new JButton("Confirm");
    	con.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
    	con.setBounds(587, 574, 110, 42);
    	bga.add(con);
    	
    	head = new JLabel(from+" to "+to);
    	head.setFont(new Font("Segoe UI Semibold", Font.BOLD, 20));
    	head.setBounds(79, 33,250, 61); 
		bga.add(head);
		
		bg = new ButtonGroup();
		ap1 = (int)(Math.random() * 3);
    	r1 = new JRadioButton("         "+a[0][ap1]);
    	r1.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		r1.setBounds(50, 163, 251, 42);
		r1.setBackground(new Color(0,0,0,0));
		r1.setForeground(Color.BLACK);
		r1.setBorder(null);
		r1.setOpaque(false);
    	bga.add(r1);
		
		ap2 = (int)(Math.random() * 3);
    	r2 = new JRadioButton("         "+a[1][ap2]);
    	r2.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		r2.setBounds(50, 242, 251, 42);
		r2.setBackground(new Color(0,0,0,0));
		r2.setForeground(Color.BLACK);
		r2.setBorder(null);
		r2.setOpaque(false);
    	bga.add(r2);
		
		ap3 = (int)(Math.random() * 3);
    	r3 = new JRadioButton("         "+a[2][ap3]);
    	r3.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		r3.setBounds(50, 321, 251, 61);
		r3.setBackground(new Color(0,0,0,0));
		r3.setForeground(Color.BLACK);
		r3.setBorder(null);
		r3.setOpaque(false);
    	bga.add(r3);
		
		ap4 = (int)(Math.random() * 3);
    	r4 = new JRadioButton("         "+a[3][ap4]);
    	r4.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		r4.setBounds(51, 396, 251, 61);
		r4.setBackground(new Color(0,0,0,0));
		r4.setForeground(Color.BLACK);
		r4.setBorder(null);
		r4.setOpaque(false);
    	bga.add(r4);
		
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		bg.add(r4);


		

    	JLabel t1 = new JLabel("5:00 to 6:30");
    	t1.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	t1.setBounds(317, 162, 117, 43);
    	bga.add(t1);
    	
    	JLabel t2 = new JLabel("8:00 to 9:30");
    	t2.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	t2.setBounds(317, 241, 117, 43);
    	bga.add(t2);
    	
    	JLabel t3 = new JLabel("14:00 to 15:30");
    	t3.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	t3.setBounds(317, 324, 117, 42);
    	bga.add(t3);
    	
    	JLabel t4 = new JLabel("21:00 to 22:30");
    	t4.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	t4.setBounds(317, 405, 117, 42);
    	bga.add(t4);
		
		cr1 =  (int)(Math.random() * 10);
    	JLabel c1 = new JLabel("Rs "+c[cr1]+"            Rs "+(q*Integer.parseInt(c[cr1])));
    	c1.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	c1.setBounds(497, 163, 200, 42);
    	bga.add(c1);
	
		cr2 =  (int)(Math.random() * 10);
        JLabel c2 = new JLabel("Rs "+c[cr2]+"            Rs "+(q*Integer.parseInt(c[cr2])));
        c2.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	c2.setBounds(497, 241, 200, 43);
        bga.add(c2);
		
		cr3 =  (int)(Math.random() * 10);
        JLabel c3 = new JLabel("Rs "+c[cr3]+"            Rs "+(q*Integer.parseInt(c[cr3])));
        c3.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	c3.setBounds(497, 324, 200, 42);
        bga.add(c3);
		
		cr4 =  (int)(Math.random() * 10);
        JLabel c4 = new JLabel("Rs "+c[cr4]+"            Rs "+(q*Integer.parseInt(c[cr4])));
        c4.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    	c4.setBounds(497, 405, 200, 43);
		bga.add(c4);

		date = new JLabel(dt+"-"+month+"-"+year);
    	date.setFont(new Font("Segoe UI Semibold", Font.BOLD, 20));
    	date.setBounds(550, 33, 182, 61);
    	bga.add(date);
		
		ba.addActionListener(this);
		con.addActionListener(this);

    }
    
    
}
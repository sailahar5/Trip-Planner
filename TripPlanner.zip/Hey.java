import java.awt.*;
import javax.swing.*;
import java.awt.event.*;



class Hey extends JFrame implements ActionListener{
       int counter = 0;
       String name;
JButton btnNewButton4;
ImageIcon icon1;
ImageIcon icon2;
String opt;
	public void actionPerformed(ActionEvent ae){
            if(ae.getSource() == btnNewButton4){
                  Homepage hp = new Homepage(name,opt);
                  hp.setSize(1000,1000);
                  hp.setTitle("Homepage");
                  hp.setVisible(true);
                  hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          
                  dispose();
            }
      }
	 Hey(String name,String opt) {
              
             this.name  = name;
             this.opt = opt;
		JPanel container = new JPanel();
        JScrollPane jsp = new JScrollPane(container);
        container.setPreferredSize(new Dimension(600,2200));
        container.setLayout(null);
            
        icon1 = new ImageIcon("Images/unlike.png");
        icon2 = new ImageIcon("Images/like.png");

        JLabel lblHelloWorld = new JLabel("             From the Community.");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 30));
        lblHelloWorld.setBounds(10, 11, 647, 45);
        container.add(lblHelloWorld);
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("Images/golden.jpg"));
        lblNewLabel.setBounds(37, 82, 469, 269);
        container.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(new ImageIcon("Images/user.png"));
        lblNewLabel_1.setBounds(37, 400, 48, 45);
        container.add(lblNewLabel_1);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.setBounds(47, 480, 32, 32);
        container.add(btnNewButton);
        btnNewButton.setIcon(icon1);
        btnNewButton.setBackground(new Color(0,0,0,0));
        btnNewButton.setBorder(null);
        btnNewButton.setOpaque(false);
        btnNewButton.addActionListener(new ActionListener() {
                    	public void actionPerformed(ActionEvent e) {
                              if( btnNewButton.getIcon() == icon1)
                              { 
                                    btnNewButton.setIcon(icon2);
                              }
                              else if(btnNewButton.getIcon() == icon2)
                              {
                                    btnNewButton.setIcon(icon1);
                              }
                    	}
                    });
        
        JLabel lblNewLabel_2 = new JLabel("<html>The Golden Temple. Located in Amritsar, it is the most sacred and divine Gurudwara, which is visited not only by Sikhs but also by people from all over the world.<br>\r\n                        <br> - Surendar,Hyderabad</html>");
        lblNewLabel_2.setFont(new Font("Century Schoolbook", Font.PLAIN, 15));
        lblNewLabel_2.setBounds(89, 386, 442, 143);
        container.add(lblNewLabel_2); 
        
        JLabel lblNewLabel_3 = new JLabel("New label");
        lblNewLabel_3.setIcon(new ImageIcon("Images/mountain.jpg"));
        lblNewLabel_3.setBounds(37, 564, 469, 269);
        container.add(lblNewLabel_3);

        JLabel label_5 = new JLabel("New label");
        label_5.setIcon(new ImageIcon("Images/user.png"));
        label_5.setBounds(37, 890, 48, 45);
        container.add(label_5);
 
  JButton btnNewButton1 = new JButton();
        btnNewButton1.setBounds(47, 965, 32, 32);
        container.add(btnNewButton1);
        btnNewButton1.setIcon(icon1);
        btnNewButton1.setBackground(new Color(0,0,0,0));
        btnNewButton1.setBorder(null);
        btnNewButton1.setOpaque(false);
        btnNewButton1.addActionListener(new ActionListener() {
                    	public void actionPerformed(ActionEvent e) {
                              if( btnNewButton1.getIcon() == icon1)
                              { 
                                    btnNewButton1.setIcon(icon2);
                              }
                              else if(btnNewButton1.getIcon() == icon2)
                              {
                                    btnNewButton1.setIcon(icon1);
                              }
                    		
                    	}
                    });

        
        JLabel lblNewLabel_4 = new JLabel("<html>A picture of Mount Everest, taken from a house in Singhwahini village in the district.A picture of the the snow-capped peaks of the Himalayas.<br>\r\n                        <br> - Pranay,Delhi</html>");
        lblNewLabel_4.setBounds(89, 868, 442, 143);
        lblNewLabel_4.setFont(new Font("Century Schoolbook", Font.PLAIN, 15));
        container.add(lblNewLabel_4);

//photo

	 JLabel lblNewLabel_6 = new JLabel("New label");
        lblNewLabel_6.setIcon(new ImageIcon("Images/s.jpg"));
        lblNewLabel_6.setBounds(37, 1046, 469, 269);
        container.add(lblNewLabel_6);

        JLabel label_7 = new JLabel("New label");
        label_7.setIcon(new ImageIcon("Images/user.png"));
        label_7.setBounds(37, 1360, 48, 45);
        container.add(label_7);

  JButton btnNewButton2 = new JButton("");
        btnNewButton2.setBounds(47, 1450, 32, 32);
        container.add(btnNewButton2);
        btnNewButton2.setIcon(icon1);
        btnNewButton2.setBackground(new Color(0,0,0,0));
        btnNewButton2.setBorder(null);
        btnNewButton2.setOpaque(false);
        btnNewButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                  if( btnNewButton2.getIcon() == icon1)
                  { 
                        btnNewButton2.setIcon(icon2);
                  }
                  else if(btnNewButton2.getIcon() == icon2)
                  {
                        btnNewButton2.setIcon(icon1);
                  }
            
            }
      });
        
        JLabel lblNewLabel_8 = new JLabel("<html>Madhya Pradesh is a must visit for stone lovers! It has many a temples, monuments, forts carved fantastically and standing tall since ages!The Khajuraho Temple known for the Kamasutra carvings, is a must see for the best in temple art.<br>\r\n                        <br> - Tilak,Bhopal</html>");
        lblNewLabel_8.setBounds(89, 1350, 442, 143);
        lblNewLabel_8.setFont(new Font("Century Schoolbook", Font.PLAIN, 15));
        container.add(lblNewLabel_8);	

//photo

        JLabel lblNewLabel_9 = new JLabel("New label");
        lblNewLabel_9.setIcon(new ImageIcon("Images/auto.jpg"));
        lblNewLabel_9.setBounds(37, 1528, 469, 269);
        container.add(lblNewLabel_9);

        JLabel label_10 = new JLabel();
        label_10.setIcon(new ImageIcon("Images/user.png"));
        label_10.setBounds(37, 1840, 48, 45);
        container.add(label_10);

  JButton btnNewButton3 = new JButton("");
        btnNewButton3.setBounds(47, 1935, 32, 32);
        container.add(btnNewButton3);
        btnNewButton3.setIcon(icon1);
        btnNewButton3.setBackground(new Color(0,0,0,0));
        btnNewButton3.setBorder(null);
        btnNewButton3.setOpaque(false);
        btnNewButton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                  if( btnNewButton3.getIcon() == icon1)
                  { 
                        btnNewButton3.setIcon(icon2);
                  }
                  else if(btnNewButton3.getIcon() == icon2)
                  {
                        btnNewButton3.setIcon(icon1);
                  }
            }
      });
        
        JLabel lblNewLabel_11 = new JLabel("<html>One of the most widely-used modes of transportation in metropolitan cities like Delhi, Mumbai and Bangalore, these 3-wheelers have given taxis a run for their money on more than one occasion.<br>\r\n                        <br> - Prasad,Bangalore</html>");
        lblNewLabel_11.setBounds(89, 1832, 442, 143);
        lblNewLabel_11.setFont(new Font("Century Schoolbook", Font.PLAIN, 15));
        container.add(lblNewLabel_11);



        btnNewButton4 = new JButton();
        btnNewButton4.setBounds(47, 2000, 48, 48);
        container.add(btnNewButton4);
        getContentPane().add(jsp);
        btnNewButton4.setIcon(new ImageIcon("Images/back.png"));
         btnNewButton4.setBackground(new Color(0,0,0,0));
         btnNewButton4.setBorder(null);
         btnNewButton4.setOpaque(false);
        btnNewButton4.addActionListener(this);

	}

	

	

}

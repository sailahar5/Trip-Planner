import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Hyderabad extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        dispose();
    }


    Hyderabad(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton("Back");
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        getContentPane().add(ba);
        
        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/golconda.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblHelloWorld = new JLabel("Hyderabad");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblkanheriCavesKanheri = new JLabel("<html>The Charminar<br>\r\n<br>\r\nIt was constructed in 1591. It has also been officially incorporated as the Emblem of Telangana. The Charminar's long history includes the existence of a mosque on its top floor for more than 400 years. It is also known for its popular and busy local markets surrounding the structure. Charminar is also a site of numerous festival celebrations, such as Eid-ul-adha and Eid-ul-fitr. The Charminar is situated on the east bank of Musi river. And to the southwest lies the richly ornamented granite Makkah Masjid. \r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 247, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Hussain Sagar<br>\r\n<br>\r\nIt is a heart-shaped lake in Hyderabad, Telangana, built by Ibrahim Quli Qutb Shah in 1563. It is spread across an area of 5.7 square kilometers and is fed by the River Musi. A large monolithic statue of the Gautama Buddha, erected in 1992, stands on Gibraltar Rock in the middle of the lake. It also separates the city centre of Hyderabad from its neighborhood Secunderabad. The maximum depth of the lake is 32 feet.</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 380, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>The Salar Jung Museum<br>\r\n<br>\r\nIt is an art museum located at Dar-ul-Shifa. It is one of the three National Museums of India. Originally a private art collection of the Salar Jung family, it was endowed to the nation after the death of Salar Jung III. It has a collection of sculptures, paintings, carvings, textiles, manuscripts, ceramics, etc from Japan, China, Burma, Nepal, India, Persia, Egypt, Europe, and North America. It is one of the largest museums in the world.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 540, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/Hyderabad1.jpg");
        label.setIcon(img2);
        label.setBounds(150, 280, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/hussain.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 420, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/salar.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 590, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>Golconda Fort<br>\r\n<br>\r\nIt is also known as Golkonda is a fortified citadel and an early capital city of the Qutb Shahi dynasty, located in Hyderabad, Telangana, India. Because of the vicinity of diamond mines, especially Kollur Mine, Golconda flourished as a trade centre of large diamonds, known as the Golconda Diamonds. The region has produced some of the world's most famous diamonds, including the colourless Koh-i-Noor, the blue Hope, etc\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);
        ba.addActionListener(this);

    }


}
import java.awt.*;
import java.awt.event.*;
import java.lang.Math;
import javax.swing.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;


class Conclusion1 extends JFrame implements ActionListener{
    
    char a[] = new char[6]; 
    JButton ba;
    String name;
    public void actionPerformed(ActionEvent ae){
        Homepage hp = new Homepage(name,"Yes");
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }
    Conclusion1(String name){
        this.name = name;
        
        getContentPane().setLayout(null);
        getContentPane().setBackground(Color.white);
        JLabel bga = new JLabel("");
        bga.setIcon(new ImageIcon("Images/ocean.png"));
        bga.setBounds(0,0,800,700);
        getContentPane().add(bga);
        
        TextField textField = new TextField();
    	textField.setForeground(Color.BLACK);
    	//textField.setEnabled(false);
    	textField.setEditable(false);
    	textField.setBackground(Color.WHITE);
    	textField.setFont(new Font("Segoe UI Semibold", Font.BOLD, 22));
    	textField.setBounds(279, 266, 116, 38);

    	bga.add(textField);

        a[0] = (char)((Math.random()*9)+'1');
        a[1] = (char)((Math.random()*9)+'1');
        a[2] = (char)((Math.random()*26)+'A');
        a[3] = (char)((Math.random()*26)+'A');
        a[4] = (char)((Math.random()*26)+'A');

        textField.setText(" tp."+a[0]+a[1]+a[2]+a[3]+a[4]);
        
        JLabel lblNewLabel = new JLabel("Use this coupon to get a 15% discount on your ticket ");
        lblNewLabel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
        lblNewLabel.setForeground(Color.RED);
        lblNewLabel.setBounds(150, 185, 411, 38);
        bga.add(lblNewLabel);
        JLabel lblNewLabel_1 = new JLabel("*This coupon can be used for 15 minutes from to book your flight");
        lblNewLabel_1.setForeground(Color.RED);
        lblNewLabel_1.setFont(new Font("Segoe UI Semibold", Font.BOLD, 13));
        lblNewLabel_1.setBounds(129, 234, 411, 23);
        bga.add(lblNewLabel_1);
        

        
        ba = new JButton("Return to Home");
        ba.setBounds(259,341,150,38);
        bga.add(ba);
       

        JButton btnNewButton = new JButton("");
        btnNewButton.setIcon(new ImageIcon("Images/irctc1.jpg"));
        btnNewButton.setBounds(283, 408, 100,100);
         btnNewButton.setBackground(new Color(0,0,0,0));
         btnNewButton.setBorder(null);
         btnNewButton.setOpaque(false);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
             Desktop d=Desktop.getDesktop();
    try {
                 d.browse(new URI("https://www.irctc.co.in/nget/train-search"));
             } catch (IOException e1) {
                 // TODO Auto-generated catch block
                 e1.printStackTrace();
             } catch (URISyntaxException e1) {
                 // TODO Auto-generated catch block
                 e1.printStackTrace();
             }
            }
        });
       
      bga.add(btnNewButton);


        JLabel lblNewLabel_2 = new JLabel("THANK YOU FOR CHOOSING US");
     lblNewLabel_2.setFont(new Font("Segoe UI Semibold", Font.BOLD, 23));
     lblNewLabel_2.setBounds(151, 58, 343, 76);
     bga.add(lblNewLabel_2);
     
     JLabel lblHaveASafe = new JLabel("HAVE A SAFE JOURNEY");
     lblHaveASafe.setFont(new Font("Segoe UI Semibold", Font.BOLD, 23));
     lblHaveASafe.setBounds(200, 115, 250, 76);
     bga.add(lblHaveASafe);


        ba.addActionListener(this);
        
    }

}


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class flight1 extends JFrame implements ActionListener{
        JButton ba;
	 JTextField fnt;
	 JTextField lnt;
	 JTextField Email;
	 JButton next;
	 String name;
	 Choice foc,toc;
	 Choice dt,month,year,choice;

         public void actionPerformed(ActionEvent ae){
			if(ae.getSource() == ba){
                Homepage hp = new Homepage(name,"Yes");
                hp.setSize(1000,1000);
                hp.setTitle("Homepage");
                hp.setVisible(true);
                hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				dispose();
			}
			if(ae.getSource() == next){
				if(lnt.getText().isEmpty()){
					Error er = new Error(name,"fl");
					er.setSize(700,200);
				er.setTitle("Error");
				er.setVisible(true);
				er.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				dispose();
				}
				else if(fnt.getText().isEmpty()){
					Error er = new Error(name,"fl");
					er.setSize(700,200);
				er.setTitle("Error");
				er.setVisible(true);
				er.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				dispose();
				}
				else if(Email.getText().isEmpty()){// 
					Error er = new Error(name,"fl");
					er.setSize(700,200);
				er.setTitle("Error");
				er.setVisible(true);
				er.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				dispose();

				}
				else if(toc.getSelectedItem() == foc.getSelectedItem()){
					Error er = new Error(name,"fl");
					er.setSize(700,200);
				er.setTitle("Error");
				er.setVisible(true);
				er.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				dispose();

				}
				else{
					flightn fn = new flightn(name,fnt.getText(),lnt.getText(),Email.getText(),toc.getSelectedItem(),foc.getSelectedItem(),dt.getSelectedItem(),month.getSelectedItem(),year.getSelectedItem(),choice.getSelectedItem());
				fn.setSize(800,700);
				fn.setTitle("Flight options");
				fn.setVisible(true);
				fn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				dispose();
				}
				
			}
            }

        flight1(String n){

			this.name = n;
			getContentPane().setLayout(null);
			
			JLabel bg = new JLabel("");
			bg.setIcon(new ImageIcon("Images/bg.jpg"));
			bg.setBounds(0,0,800,700);
			getContentPane().add(bg);

			fnt = new JTextField();
			fnt.setBounds(146, 75, 162, 34);
			fnt.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
        	bg.add(fnt);
        	fnt.setColumns(10);
			
        	JLabel fn = new JLabel("First Name");
        	fn.setBounds(62, 82, 92, 17);
        	fn.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
        	bg.add(fn);
			
			
			
        	JLabel ln = new JLabel("Last Name");
        	ln.setBounds(62, 158, 75, 14);
        	ln.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
        	bg.add(ln);
        	
        	lnt = new JTextField();
			lnt.setBounds(146, 150, 162, 35);
			lnt.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
        	bg.add(lnt);
        	lnt.setColumns(10);
        	
        	JLabel date = new JLabel("Date");
        	date.setBounds(62, 313, 46, 14);
        	date.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
        	bg.add(date);
        	
        	dt = new Choice();
        	dt.setBounds(146, 313, 162,18);
        	bg.add(dt);
        	
        	month = new Choice();
        	month.setBounds(359, 313, 133, 34);
        	bg.add(month);
        	
        	year = new Choice();
        	year.setBounds(555, 313, 92, 22);
        	bg.add(year);
        	
        	toc = new Choice();
        	toc.setBounds(146, 375, 119, 18);
        	bg.add(toc);
        	
        	toc.add("Hyderabad");
        	toc.add("Ahmedabad");
        	toc.add("Jaipur"); 
        	toc.add("Shimla");
        	toc.add("Goa");
        	toc.add("Mumbai");
        	toc.add("Chennai");
        	toc.add("Kolkata");
        	toc.add("Bangalore");
        	toc.add("Delhi");
        	
        	JLabel to = new JLabel("To");
        	to.setBounds(62, 375, 46, 17);
        	to.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
        	bg.add(to);
        	
        	JLabel from = new JLabel("From");
        	from.setBounds(313, 379, 46, 14);
        	from.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
        	bg.add(from);
        	
        	foc = new Choice();
        	foc.setBounds(359, 375, 110, 18);
        	bg.add(foc);
        	
        	foc.add("Hyderabad");
        	foc.add("Ahmedabad");
        	foc.add("Jaipur");
        	foc.add("Shimla");
        	foc.add("Goa");
        	foc.add("Mumbai");
        	foc.add("Chennai");
        	foc.add("Kolkata");
        	foc.add("Bangalore");
        	foc.add("Delhi");
        	
        	for(int i=19;i<30;i++){
        		year.add("20"+(i+1));
            }
        	
        	
        	month.add("January");
        	month.add("February");
        	month.add("March");
        	month.add("April");
        	month.add("April");
        	month.add("May");
        	month.add("June");
        	month.add("July");
        	month.add("August");
        	month.add("September");
        	month.add("October");
        	month.add("November");
        	month.add("December");
        	
        	for(int i=0;i<31;i++){
                dt.add(""+(i+1));
            }
            ba = new JButton("Back");
			ba.setBounds(50, 541, 133, 23);
			ba.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
            bg.add(ba);
			ba.addActionListener(this);
			
			next = new JButton("Show all flights");
			next.setBounds(480, 550, 133, 23);
        	next.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
			bg.add(next);
			
			Email = new JTextField();
			Email.setBounds(146, 235, 162, 34);
			Email.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
			Email.setColumns(10);
			bg.add(Email);
			
			JLabel lblEmail = new JLabel("Email");
			lblEmail.setBounds(62, 244, 75, 14);
			lblEmail.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
			bg.add(lblEmail);
			
			JLabel lblNewLabel = new JLabel("* Your details are taken to send a the confirmation of the coupon generated for your flight");
			lblNewLabel.setForeground(Color.WHITE);
			lblNewLabel.setBounds(105, 11, 533, 34);
			bg.add(lblNewLabel);
			
			choice = new Choice();
			choice.setBounds(150, 446, 99, 18);
			bg.add(choice);
			for(int i=0;i<5;i++){
                choice.add(""+(i+1));
            }
			
			
			JLabel lblNumberOfPeople = new JLabel("Number of people");
			lblNumberOfPeople.setBounds(22, 439, 133, 25);
			lblNumberOfPeople.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
			bg.add(lblNumberOfPeople);
			next.addActionListener(this);

        }

        
}
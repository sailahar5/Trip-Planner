
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



class Mumbai extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Mumbai(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton("Back");
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        getContentPane().add(ba);
        
        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/gate.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblHelloWorld = new JLabel("Mumbai");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblkanheriCavesKanheri = new JLabel("<html>Kanheri caves<br>\r\n<br>\r\n\r\nKanheri Caves whose period of establishment dates back to anywhere between 1st Century BC and 11th Century AD is one of the finest examples of the Indian rock cut architecture. Located in the heart of the beautiful green environs of Sanjay Gandhi National Park of Maharashtra, Kanheri Caves is about 10 km from the Borivali Station and 45 km from main Mumbai. These caves perhaps are the only symbol which depicts the rise and fall of Buddhism in Western India.</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 247, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Fort George<br>\r\n<br>\r\n\r\nFort George, Bombay. Fort George was an extension to the fortified walls of Bombay (now Mumbai) built in 1769; it was in the present-day Fort area, to the east of the site of the former Dongri Fort. The hill on which the Dongri fort stood was razed, and in its place Fort George was built.</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 380, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>Chhatrapati shivaji maharaj vastu sangrahalaya<br>\r\n<br>\r\nChhatrapati Shivaji Maharaj Vastu Sangrahalaya, formerly known as the Prince of Wales Museum of Western India, is one of the premier art and history museum in India. Situated on the southern tip of Mumbai on the 'Crescent Site', the Museum building is a fine example of the Indo-Saracenic style of architecture.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 528, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/caves.jpg");
        label.setIcon(img2);
        label.setBounds(150, 280, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/george.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 420, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/shivaji.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 570, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>Gateway of India<br>\r\n<br>\r\n\r\nThe Gateway of India is located on the waterfront at Apollo Bunder area at the end of Chhatrapati Shivaji Marg in South Mumbai and overlooks the Arabian Sea. The monument has also been referred to as the Taj Mahal of Mumbai, and is the city's top tourist attraction.</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);
        ba.addActionListener(this);
    }


}
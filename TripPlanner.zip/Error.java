import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Error extends JFrame implements ActionListener{
    String b;
    String name;

    public void actionPerformed(ActionEvent ae){
        if(b.equals("fl")){
            flight1 fl = new flight1(name);
            fl.setSize(800,700);
            fl.setTitle("flight");
            fl.setVisible(true);
            dispose();
        }
        else{
            trains1 tr = new trains1(name);
            tr.setSize(800,700);
            tr.setTitle("Trains");
            tr.setVisible(true);
            dispose();
        }
        
    }
    Error(String name,String b){
        this.name = name;
        this.b = b;
    	getContentPane().setLayout(null);
    	
    	JLabel lblNewLabel = new JLabel("Please enter your first name, lastname,Email and select different to and from options");
    	lblNewLabel.setBounds(70, 36, 500, 14);
    	getContentPane().add(lblNewLabel);
    	
    	JButton ba = new JButton("OK");
    	ba.setBounds(250, 91, 80, 23);
        getContentPane().add(ba);
        
        ba.addActionListener(this);

    }
    

}

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Delhi extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Delhi(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton();
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        
        getContentPane().add(ba);
        
        JLabel lblHelloWorld = new JLabel("Delhi");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/red.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblkanheriCavesKanheri = new JLabel("<html>The India Gate<br>\r\n<br>\r\nIt is a war memorial located astride the Rajpath, on the eastern edge of New Delhi. 13,300 servicemen's names, including some soldiers and officers from the United Kingdom, are inscribed on the gate. Designed by Sir Edwin Lutyens, the gate evokes the architectural style of the triumphal arch such as the Arch of Constantine, in Rome, and is often compared to the Arc de Triomphe in Paris, and the Gateway of India in Mumbai.This structure, called Amar Jawan Jyoti, has since 1971 served as India's tomb of the unknown soldier. \r\n</html>\r\n\n");
        lblkanheriCavesKanheri.setBounds(324, 247, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Qutab Minar<br>\r\n<br>\r\nIt is a minaret and \"victory tower\" that forms part of the Qutb complex, a UNESCO World Heritage Site in the Mehrauli area of Delhi.Qutb Minar was 73-metres tall before the final, fifth section was added after 1369. The tower tapers, and has a 14.3 metres base diameter, reducing to 2.7 metres at the top of the peak. It contains a spiral staircase of 379 steps. The surfaces of both are elaborately decorated with inscriptions and geometric patterns.\r\n</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 380, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>Humayun's tomb<br>\r\n<br>\r\nIt is the tomb of the Mughal Emperor Humayun in Delhi, India. The tomb was designed by Mirak Mirza Ghiyas and his son, Sayyid Muhammad, Persian architects chosen by her. It was the first garden-tomb on the Indian subcontinent, and is located in Nizamuddin East, Delhi.It was also the first structure to use red sandstone at such a scale.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 528, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/india.jpg");
        label.setIcon(img2);
        label.setBounds(150, 280, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/qutab.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 420, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/tomb.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 570, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>The Red Fort<br>\r\n<br>\r\nIt is a historic fort in the city of Delhi in India, which served as the main residence of the Mughal Emperors. Emperor Shah Jahan commissioned construction of the Red Fort on 12 May 1638, when he decided to shift his capital from Agra to Delhi. Its design is credited to architect Ustad Ahmad Lahori, who also constructed the Taj Mahal. On 15 August 1947, the first prime minister of India, Jawaharlal Nehru, raised the Indian national flag above the Lahori Gate. Every year on India's Independence Day, the prime minister hoists the Indian \"tricolour flag\" at the fort's main gate \r\n\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);
        ba.addActionListener(this);

    }


}
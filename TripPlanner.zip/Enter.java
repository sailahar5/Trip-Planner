import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;
import java.net.URI;
import java.net.URISyntaxException;

class Enter extends JFrame implements ActionListener{
     TextField textField_1;
     JTextField textField;
     JButton log;
     JButton log1;
     JLabel lblNewLabelBackground;

     public void actionPerformed(ActionEvent ae){
         if(ae.getSource() == log){
             if(textField.getText().isEmpty()){
                Error5 er = new Error5();
                er.setSize(400,200);
                er.setTitle("Error");
                er.setVisible(true);
                er.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                dispose();
             }
             else if(textField_1.getText().isEmpty()){
                Error5 er = new Error5();
                er.setSize(400,200);
                er.setTitle("Flight options");
                er.setVisible(true);
                er.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                dispose();
             }
             else{
                Homepage hp = new Homepage(textField.getText(),"Yes");
                hp.setSize(1000,1000);
                hp.setTitle("Homepage");
                hp.setVisible(true);
                hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                dispose();
             }
            
         }
         if(ae.getSource() == log1){
            Homepage hp = new Homepage("guest","No");
            hp.setSize(1000,1000);
            hp.setTitle("Homepage");
            hp.setVisible(true);
            hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            dispose();
         }

     }
    Enter(){
    	getContentPane().setLayout(null);
    	
    	JLabel user = new JLabel("Username");
    	user.setBounds(67, 166, 167, 29);
    	user.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
    	getContentPane().add(user);
    	
    	JLabel pass = new JLabel("Password");
    	pass.setBounds(67, 215, 132, 23);
    	pass.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
    	getContentPane().add(pass);
    	
    	textField_1 = new TextField();
    	textField_1.setBounds(230, 210, 128, 26);
        textField_1.setEchoChar('*');
    	getContentPane().add(textField_1);
    	// textField_1.setColumns(10);
    	
    	textField = new JTextField();
    	textField.setBounds(230, 170, 128, 26);
    	// textField.setColumns(10);
    	getContentPane().add(textField);
    	
    	log = new JButton("  Login");
    	log.setBounds(149, 270, 173, 51);
    	log.setIcon(new ImageIcon("Images/login.png"));
    	log.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
    	getContentPane().add(log);
    	
    	log1 = new JButton(" Login as guest");
    	log1.setIcon(new ImageIcon("Images/guest.png"));
    	log1.setBounds(116, 350, 242, 59);
    	log1.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
        getContentPane().add(log1);
        
        lblNewLabelBackground = new JLabel("");
        lblNewLabelBackground.setIcon(new ImageIcon("Images/edited.jpg"));
        lblNewLabelBackground.setBounds(10, 11, 966, 689);
        getContentPane().add(lblNewLabelBackground);


        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("Images/logo1.png"));
        lblNewLabel.setBounds(100, 23, 189, 132);
       lblNewLabelBackground.add(lblNewLabel);

JButton btnNewButton = new JButton("");
       btnNewButton.setIcon(new ImageIcon("Images/insta2_48.png"));
       btnNewButton.setBounds(750, 585, 48,48);
        btnNewButton.setBackground(new Color(0,0,0,0));
        btnNewButton.setBorder(null);
        btnNewButton.setOpaque(false);
       btnNewButton.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
            Desktop d=Desktop.getDesktop();
   try {
				d.browse(new URI("https://www.instagram.com/trip___planner/"));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (URISyntaxException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
       	}
       });
      
     lblNewLabelBackground.add(btnNewButton);

JButton btnNewButton1 = new JButton("");
       btnNewButton1.setIcon(new ImageIcon("Images/fb.png"));
       btnNewButton1.setBounds(850, 585, 48,48);
        btnNewButton1.setBackground(new Color(0,0,0,0));
        btnNewButton1.setBorder(null);
        btnNewButton1.setOpaque(false);
       btnNewButton1.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
            Desktop d=Desktop.getDesktop();
   try {
				d.browse(new URI("https://www.facebook.com/trip.planner.3726"));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (URISyntaxException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
       	}
       });
      
     lblNewLabelBackground.add(btnNewButton1);



        log.addActionListener(this);
        log1.addActionListener(this);
        
    }
    public static void main(String[] args) {
        Enter e = new Enter();
        e.setSize(1000,700);
        e.setTitle("Login");
        e.setVisible(true);
        e.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    }
}



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class Jaipur extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Jaipur(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        ba = new JButton("Back");
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        getContentPane().add(ba);
        
        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/city.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblHelloWorld = new JLabel("Jaipur");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblkanheriCavesKanheri = new JLabel("<html>Jal Mahal<br>\r\n<br>\r\nJal Mahal is a palace in the middle of the Man Sagar Lake in Jaipur city, the capital of the state of Rajasthan, India. The palace and the lake around it were renovated and enlarged in the 18th century by Maharaja Jai Singh II of Amber.\r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 235, 425, 175);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Jaigarh Fort<br>\r\n<br>\r\nJaigarh Fort is situated on the promontory called the Cheel ka Teela of the Aravalli range; it overlooks the Amer Fort and the Maota Lake, near Amer in Jaipur, Rajasthan, India. The fort was built by Jai Singh II in 1726 to protect the Amer Fort and its palace complex and was named after him</html>\r\n");
        lblfortGeorgeFort.setBounds(324, 380, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>Jantar mantar<br>\r\n<br>\r\nThe Jantar Mantar is a collection of nineteen architectural astronomical instruments built by the Rajput king Sawai Jai Singh II, the founder of Jaipur, Rajasthan. The monument was completed in 1734. It features the world's largest stone sundial, and is a UNESCO World Heritage site.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 528, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/india.jpg");
        label.setIcon(img2);
        label.setBounds(150, 280, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/jal.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 420, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/jantar.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 570, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>City palace<br>\r\n<br>\r\nLocated in the heart of the Pink City Jaipur, the City Palace was where the Maharaja reigned from. This palace also includes the famous 'Chandra Mahal' and 'Mubarak Mahal', and other buildings which form a part of the palace complex. The palace is located towards the northeast side of central Jaipur and has many courtyards and buildings. The palace was built between 1729 and 1732 AD by Sawai Jai Singh II. He ruled in Amer and planned and built the outer walls of the palace and later rulers added to the architecture of this palace. These additions have been known to take place right up to the 20th century.\r\n\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 55, 417, 170);
        getContentPane().add(lblNewLabel_1);
        ba.addActionListener(this);

    }


}
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Enter extends JFrame{ //implements ActionListener
     TextField textField_1;
     JTextField textField;
     JButton log;
     JButton log1;
     private JLabel lblNewLabelBackground;

    /* public void actionPerformed(ActionEvent ae){
         if(ae.getSource() == log){
            Homepage hp = new Homepage(textField.getText());
            hp.setSize(1000,1000);
            hp.setTitle("Homepage");
            hp.setVisible(true);
            hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            dispose();
         }
         if(ae.getSource() == log1){
            Homepage hp = new Homepage("guest");
            hp.setSize(1000,1000);
            hp.setTitle("Homepage");
            hp.setVisible(true);
            hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            dispose();
         }

     }*/
    Enter(){
    	getContentPane().setLayout(null);
    	
    	JLabel user = new JLabel("Username");
    	user.setBounds(67, 166, 167, 29);
    	user.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
    	getContentPane().add(user);
    	
    	JLabel pass = new JLabel("Password");
    	pass.setBounds(67, 215, 132, 23);
    	pass.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
    	getContentPane().add(pass);
    	
    	textField_1 = new TextField();
    	textField_1.setBounds(230, 210, 128, 26);
        textField_1.setEchoChar('*');
    	getContentPane().add(textField_1);
    	// textField_1.setColumns(10);
    	
    	textField = new JTextField();
    	textField.setBounds(230, 170, 128, 26);
    	// textField.setColumns(10);
    	getContentPane().add(textField);
    	
    	log = new JButton("  Login");
    	log.setBounds(149, 270, 173, 51);
    	log.setIcon(new ImageIcon("login.png"));
    	log.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
    	getContentPane().add(log);
    	
    	log1 = new JButton(" Login as guest");
    	log1.setIcon(new ImageIcon("guest.png"));
    	log1.setBounds(116, 350, 242, 59);
    	log1.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
        getContentPane().add(log1);
        
        lblNewLabelBackground = new JLabel("");
        lblNewLabelBackground.setIcon(new ImageIcon("edited.jpg"));
        lblNewLabelBackground.setBounds(10, 11, 966, 689);
        getContentPane().add(lblNewLabelBackground);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("logo1.png"));
        lblNewLabel.setBounds(100, 23, 189, 132);
       lblNewLabelBackground .add(lblNewLabel);
        
        
       // log.addActionListener(this);
       // log1.addActionListener(this);
        
    }
    public static void main(String[] args) {
        Enter e = new Enter();
        e.setSize(1000,1000);
        e.setTitle("Login");
        e.setVisible(true);
        e.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    }
}


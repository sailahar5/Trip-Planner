import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class Homepage extends JFrame implements ActionListener{//
    JMenuBar mb;
    JMenu cities,flights,trains;
    JMenuItem hyd,ahm,jai,shi,goa,mum,che,kol,ban,del,bk1,bk2;
    String s;
    String n;
    JLabel background;
    ImageIcon back;
    JButton h,a,j,sh,g,m,ch,k,b,d,lo;
    JLabel name;
    JLabel label;
    JLabel label_1;
    JPanel panel_1,panel_2,panel_3,panel_4,panel_5,panel_6,panel_7,panel_8,panel_9,panel_10,panel_11,panel_12;
    JPanel panel;
    JLabel bbBackground;
    JButton hey;
    String opt;
    // JButton h,a,j,sh,g,m,ch,k,b,d;
    
    Homepage(String str,String opt){
        this.n = str;
        this.opt = opt;
        Container c = getContentPane();
        c.setBackground(Color.white);
         c.setLayout(null);
           
        mb = new JMenuBar();
        
        
        setJMenuBar(mb);
        cities = new JMenu("Cities");
        flights = new JMenu("Flights");
        trains = new JMenu("Trains");
        if(opt.equals("No")){
            flights.setEnabled(false);
            trains.setEnabled(false);
            
        }
         
       
        
        background = new JLabel("",back,JLabel.CENTER);
        background.setBounds(0,200,991,800);
        mb.add(cities);
        mb.add(flights);
        mb.add(trains);
        hyd = new JMenuItem("Hyderabad");
        ahm = new JMenuItem("Ahmedabad");
        jai = new JMenuItem("Jaipur");
        shi = new JMenuItem("Shimla");
        goa = new JMenuItem("Goa");
        mum = new JMenuItem("Mumbai");
        che = new JMenuItem("Chennai");
        kol = new JMenuItem("Kolkata");
        ban = new JMenuItem("Bangalore");
        del = new JMenuItem("Delhi");
        bk1 = new JMenuItem("Find a Plane");
        bk2 = new JMenuItem("Find a train");

        cities.add(hyd);
        cities.add(ahm);
        cities.add(jai);
        cities.add(shi);
        cities.add(goa);
        cities.add(mum);
        cities.add(che);
        cities.add(kol);
        cities.add(ban);
        cities.add(del);

        cities.addSeparator();
        
        
        

        
        flights.add(bk1);
        flights.addSeparator();
        trains.add(bk2);
        trains.addSeparator();

     
    JLabel bb = new JLabel("New label");
       bb.setForeground(Color.WHITE);
       bb.setBackground(Color.WHITE);
       bb.setBounds(100, 120, 800, 800);
       bb.setIcon(new ImageIcon("Images/indiadarkblue.jpg"));
       getContentPane().add(bb);
 
       name = new JLabel("Hi "+n+", Where do you wanna go !!!");
       getContentPane().add(name);
       name.setBounds(10, 32, 600, 50);
        name.setForeground(Color.black);
       name.setFont(new Font("Century Schoolbook",  Font.BOLD |Font.ITALIC, 25));

       JLabel logo = new JLabel("");
        logo.setIcon(new ImageIcon("Images/logo1.png"));
        logo.setBounds(700, 0, 189, 132);
        getContentPane().add(logo);

                 panel_1 = new JPanel();
                 panel_1.setBounds(250, 520, 150, 170);
                 panel_1.setLayout(null);
                 panel_1.setOpaque(false);
                bb.add(panel_1);
                h = new JButton("Hyderabad");
       	 	    h.setFont(new Font("Tahoma", Font.PLAIN, 14));
                    h.setBounds(0, 0, 114, 27);
                    h.setIcon(new ImageIcon("Images/pin1.png"));
                   h.setBackground(new Color(0,0,0,0));
                   h.setBorder(null);
                h.setForeground(Color.white);
                h.setOpaque(false);
  		  		panel_1.add(h);  
                                  
                    panel_2 = new JPanel();
                    panel_2.setBounds(120, 380, 150, 170);
                    panel_2.setLayout(null);
                     panel_2.setOpaque(false);
                     bb.add(panel_2);
                     a = new JButton("Ahmedabad");
       	 	        a.setFont(new Font("Tahoma", Font.PLAIN, 14));
       	 	        a.setBounds(0, 0, 114, 27);
                    a.setBackground(new Color(0,0,0,0));
                    a.setIcon(new ImageIcon("Images/pin1.png"));
                    a.setBorder(null);
                    a.setForeground(Color.white);
                    a.setOpaque(false);
                    panel_2.add(a); 
			                      		  		          
                    panel_3 = new JPanel();
                    panel_3.setBounds(180, 280, 150, 170);
                    panel_3.setLayout(null);
                     panel_3.setOpaque(false);
                     bb.add(panel_3);
                     j = new JButton("Jaipur");
                     j.setIcon(new ImageIcon("Images/pin1.png"));
       	 	        j.setFont(new Font("Tahoma", Font.PLAIN, 14));
       	 	        j.setBounds(0, 0, 114, 27);
                    j.setBackground(new Color(0,0,0,0));
                    j.setBorder(null);
                    j.setForeground(Color.white);
                    j.setOpaque(false);
                    panel_3.add(j);
                    
                    

                    panel_4 = new JPanel();
                    panel_4.setBounds(220,180, 150, 170);
                    panel_4.setLayout(null);
                     panel_4.setOpaque(false);
                     bb.add(panel_4);
                     sh = new JButton("Shimla");
                        sh.setFont(new Font("Tahoma", Font.PLAIN, 14));
                        sh.setIcon(new ImageIcon("Images/pin1.png"));
       	 	        sh.setBounds(0, 0, 114, 27);
                    sh.setBackground(new Color(0,0,0,0));
                    sh.setBorder(null);
                    sh.setForeground(Color.white);
                    sh.setOpaque(false);
                    panel_4.add(sh); 
                    
                    

                    panel_5 = new JPanel();
                    panel_5.setBounds(135,570, 150, 170);
                    panel_5.setLayout(null);
                     panel_5.setOpaque(false);
                     bb.add(panel_5);
                     g = new JButton("Goa");
                        g.setFont(new Font("Tahoma", Font.PLAIN, 14));
                        g.setIcon(new ImageIcon("Images/pin1.png"));
       	 	        g.setBounds(0, 0, 114, 27);
                    g.setBackground(new Color(0,0,0,0));
                    g.setBorder(null);
                    g.setForeground(Color.white);
                    g.setOpaque(false);
                    panel_5.add(g);  
                    
                    
                    panel_6 = new JPanel();
                    panel_6.setBounds(130,455, 150, 170);
                    panel_6.setLayout(null);
                     panel_6.setOpaque(false);
                     bb.add(panel_6);
                     m = new JButton("Mumbai");
                     m.setIcon(new ImageIcon("Images/pin1.png"));
       	 	        m.setFont(new Font("Tahoma", Font.PLAIN, 14));
       	 	        m.setBounds(0, 0, 114, 27);
                    m.setBackground(new Color(0,0,0,0));
                    m.setBorder(null);
                    m.setForeground(Color.white);
                    m.setOpaque(false);
                    panel_6.add(m);   
                    
                    panel_7 = new JPanel();
                    panel_7.setBounds(285,620, 150, 170);
                    panel_7.setLayout(null);
                     panel_7.setOpaque(false);
                     bb.add(panel_7);
                     ch = new JButton("Chennai");
                        ch.setFont(new Font("Tahoma", Font.PLAIN, 14));
                        ch.setIcon(new ImageIcon("Images/pin1.png"));
       	 	        ch.setBounds(0, 0, 114, 27);
                    ch.setBackground(new Color(0,0,0,0));
                    ch.setBorder(null);
                    ch.setForeground(Color.white);
                   ch.setOpaque(false);
                    panel_7.add(ch);  

                    panel_8 = new JPanel();
                    panel_8.setBounds(450,380, 150, 170);
                    panel_8.setLayout(null);
                     panel_8.setOpaque(false);
                     bb.add(panel_8);
                     k = new JButton("Kolkata");
                        k.setFont(new Font("Tahoma", Font.PLAIN, 14));
                        k.setIcon(new ImageIcon("Images/pin1.png"));
       	 	        k.setBounds(0, 0, 114, 27);
                    k.setBackground(new Color(0,0,0,0));
                    k.setBorder(null);
                    k.setForeground(Color.white);
                   k.setOpaque(false);
                    panel_8.add(k);  


                    panel_9 = new JPanel();
                    panel_9.setBounds(220,635, 150, 170);
                    panel_9.setLayout(null);
                     panel_9.setOpaque(false);
                     bb.add(panel_9);
                     b = new JButton("Bangalore");
       	 	        b.setFont(new Font("Tahoma", Font.PLAIN, 14));
                        b.setBounds(0, 0, 114, 27);
                        b.setIcon(new ImageIcon("Images/pin1.png"));
                    b.setBackground(new Color(0,0,0,0));
                    b.setBorder(null);
                    b.setForeground(Color.white);
                   b.setOpaque(false);
                    panel_9.add(b);  


                    panel_10 = new JPanel();
                    panel_10.setBounds(210,230, 150, 170);
                    panel_10.setLayout(null);
                     panel_10.setOpaque(false);
                     bb.add(panel_10);
                     d = new JButton("Delhi");
       	 	        d.setFont(new Font("Tahoma", Font.PLAIN, 14));
                        d.setBounds(0, 0, 114, 27);
                        d.setIcon(new ImageIcon("Images/pin1.png"));
                    d.setBackground(new Color(0,0,0,0));
                    d.setBorder(null);
                    d.setForeground(Color.white);
                   d.setOpaque(false);
                    panel_10.add(d);  

                    panel_11 = new JPanel();
                    panel_11.setBounds(620,630, 250, 300);
                    panel_11.setLayout(null);
                    panel_11.setBackground(Color.WHITE);
                     bb.add(panel_11);
                  
                     hey = new JButton("   Reviews");
                    hey.setIcon(new ImageIcon("Images/re1.jpg"));
                    hey.setBackground(new Color(0,0,0,0));
                    hey.setBorder(null);
                    hey.setOpaque(false);
       	   hey.setBounds(0, 0, 250,60);
                    panel_11.add(hey); 

                    panel_12 = new JPanel();
                    panel_12.setBounds(0,630,100, 300);
                    panel_12.setLayout(null);
                    panel_12.setBackground(Color.WHITE);
                    bb.add(panel_12);
                 
                    lo = new JButton("   Log Out");
                  // hey.setIcon(new ImageIcon("Images/re1.jpg"));
                  //  hey.setBackground(new Color(0,0,0,0));
                  //  hey.setBorder(null);
                  // hey.setOpaque(false);
       	     lo.setBounds(0, 0, 90,40);
                      panel_12.add(lo); 
                    

                  



    
    
        hyd.addActionListener(this);
       ahm.addActionListener(this);
       jai.addActionListener(this);
       shi.addActionListener(this);
       goa.addActionListener(this);
       mum.addActionListener(this);
       che.addActionListener(this);
       kol.addActionListener(this);
       ban.addActionListener(this);
       del.addActionListener(this);
       bk1.addActionListener(this);
       bk2.addActionListener(this);
        hey.addActionListener(this);
       h.addActionListener(this);
       a.addActionListener(this);
       j.addActionListener(this);
       sh.addActionListener(this);
       g.addActionListener(this);
       m.addActionListener(this);
       ch.addActionListener(this);
       k.addActionListener(this);
       b.addActionListener(this);
       d.addActionListener(this);
       lo.addActionListener(this);
    }

    

   public void actionPerformed(ActionEvent ae){
       if(hyd.isArmed()){
           Hyderabad h = new Hyderabad(n,opt);
           h.setSize(800,800);
           h.setVisible(true);
           dispose();
           
       }
       if(ahm.isArmed()){
           Ahmedabad ah = new Ahmedabad(n,opt);
           ah.setSize(800,800);
           ah.setVisible(true);
           dispose();

       }
       if(jai.isArmed()){
           Jaipur j = new Jaipur(n,opt);
           j.setSize(800,800);
           j.setVisible(true);
           dispose();

       }
       if(shi.isArmed()){
           Shimla s = new Shimla(n,opt);
           s.setSize(800,800);
           s.setVisible(true);
           dispose();

       }
       if(goa.isArmed()){
           Goa g = new Goa(n,opt);
           g.setSize(800,800);
           g.setVisible(true);
           dispose();

       }
       if(mum.isArmed()){
           Mumbai m = new Mumbai(n,opt);
           m.setSize(800,800);
           m.setVisible(true);
           dispose();

       }
       if(che.isArmed()){
           Chennai c = new Chennai(n,opt);
           c.setSize(800,800);
           c.setVisible(true);
           dispose();

       }
       if(kol.isArmed()){
           Kolkata k = new Kolkata(n,opt);
           k.setSize(800,800);
           k.setVisible(true);
           dispose();

       }
       if(ban.isArmed()){
           Bangalore b = new Bangalore(n,opt);
            b.setSize(800,800);
          b.setVisible(true);
           dispose();
       }
       if(del.isArmed()){
           Delhi d = new Delhi(n,opt);
           d.setSize(800,800);
           d.setVisible(true);
           dispose();

       }
       if(bk1.isArmed()){
           flight1 fl = new flight1(n);
           fl.setSize(800,700);
           fl.setTitle("flight");
           fl.setVisible(true);
           dispose();

       }
       if(bk2.isArmed()){
       trains1 tr = new trains1(n);
       tr.setSize(800,700);
       tr.setTitle("Trains");
       tr.setVisible(true);
       dispose();

       }
       
       if(ae.getSource()==h){
           Hyderabad h = new Hyderabad(n,opt);
           h.setSize(800,800);
           h.setVisible(true);
           dispose();
       }
       if(ae.getSource()==a){
        Ahmedabad ah = new Ahmedabad(n,opt);
        ah.setSize(800,800);
        ah.setVisible(true);
        dispose();

    }
    if(ae.getSource()==j){
        Jaipur j = new Jaipur(n,opt);
        j.setSize(800,800);
        j.setVisible(true);
        dispose();

    }
    if(ae.getSource()==sh){
        Shimla s = new Shimla(n,opt);
        s.setSize(800,800);
        s.setVisible(true);
        dispose();

    }
    if(ae.getSource()==g){
        Goa g = new Goa(n,opt);
        g.setSize(800,800);
        g.setVisible(true);
        dispose();

    }
    if(ae.getSource()==m){
        Mumbai m = new Mumbai(n,opt);
        m.setSize(800,800);
        m.setVisible(true);
        dispose();

    }
    if(ae.getSource()==ch){
        Chennai c = new Chennai(n,opt);
        c.setSize(800,800);
        c.setVisible(true);
        dispose();

    }
    if(ae.getSource()==k){
        Kolkata k = new Kolkata(n,opt);
        k.setSize(800,800);
        k.setVisible(true);
        dispose();

    }
    if(ae.getSource()==b){
        Bangalore b = new Bangalore(n,opt);
         b.setSize(800,800);
        b.setVisible(true);
        dispose();
    }
    if(ae.getSource()==d){
        Delhi d = new Delhi(n,opt);
        d.setSize(800,800);
        d.setVisible(true);
        dispose();

    }
    if(ae.getSource()==hey){
        Hey hy = new Hey(n,opt);
        hy.setBounds(100, 100, 600,1800);
        hy.setVisible(true);
    hy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    dispose();
}
  if(ae.getSource()==lo){
    Enter e = new Enter();
    e.setSize(1000,700);
    e.setTitle("Login");
    e.setVisible(true);
    e.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    dispose();


    }
       

   }
   
   
}

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Ahmedabad extends JFrame implements ActionListener{
    JButton ba;
    JLabel l;
    String name;
    String opt;
    
    public void actionPerformed(ActionEvent ae){

        Homepage hp = new Homepage(name,opt);
        hp.setSize(1000,1000);
        hp.setTitle("Homepage");
        hp.setVisible(true);
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dispose();
    }

    Ahmedabad(String n,String opt){
        this.name = n;
        this.opt = opt;
        getContentPane().setLayout(null);
        // getContentPane().setBackground(Color.BLUE);
        ba = new JButton();
        ba.setIcon(new ImageIcon("Images/back.png"));
        ba.setBounds(50, 700, 48, 48);
        ba.setBackground(new Color(0,0,0,0));
        ba.setBorder(null);
        ba.setOpaque(false);
        getContentPane().add(ba);
        
        JLabel lblHelloWorld = new JLabel("Ahmedabad");
        lblHelloWorld.setFont(new Font("Century Schoolbook", Font.BOLD | Font.ITALIC, 25));
        lblHelloWorld.setBounds(324, 11, 250, 45);
        getContentPane().add(lblHelloWorld);

        JLabel lblNewLabel = new JLabel("New label");
        ImageIcon img1 = new ImageIcon("Images/ashram.jpg");
        lblNewLabel.setIcon(img1);
        lblNewLabel.setBounds(150, 95, 117, 110);
        getContentPane().add(lblNewLabel);
        
        JLabel lblkanheriCavesKanheri = new JLabel("<html><span>Adalaj Stepwell</span> <br>\r\n<br>\r\nAdalaj Stepwell or Rudabai Stepwell is a stepwell located in the village of Adalaj, close to Ahmedabad city and in Gandhinagar district in the Indian state of Gujarat, and considered a fine example of Indian architecture work. It was built in 1498 in the memory of Rana Veer Singh, by his wife Queen Rudadevi.\r\n</html>\r\n");
        lblkanheriCavesKanheri.setBounds(324, 217, 425, 165);
        getContentPane().add(lblkanheriCavesKanheri);
        
        JLabel lblfortGeorgeFort = new JLabel("<html>Kankaria Lake<br>\r\n<br>\r\nIt is the second largest lake in Ahmedabad. It is located in the south-eastern part of the city. It was completed in 1451 during the reign of Sultan Qutb-ud-Din Ahmad Shah II. A lakefront is developed around it, which has many public attractions such as a zoo, toy train, kids city, tethered balloon ride, etc. Kankaria Carnival is a week-long festival held in the last week of December. Many cultural, art, and social activities are organised during the carnival. </html>\r\n");
        lblfortGeorgeFort.setBounds(324, 338, 425, 217);
        getContentPane().add(lblfortGeorgeFort);
        
        JLabel lblChhatrapatiShivaji = new JLabel("<html>Sardar Vallabhbhai Patel National Memorial<br>\r\n\r\n<br>\r\nThe Moti Shahi Mahal is a palace built by the Mughal emperor Shahjahan between 1618 and 1622. It now hosts the Sardar Vallabhbhai Patel National Memorial, which is a museum and exhibition centre dedicated to Vallabhbhai Patel located in Shahibaug, Ahmedabad, Gujarat, near Civil Hospital, Ahmedabad. It is surrounded by well laid gardens.</html>\r\n");
        lblChhatrapatiShivaji.setBounds(324, 498, 425, 195);
        getContentPane().add(lblChhatrapatiShivaji);
        
        JLabel label = new JLabel("New label");
        ImageIcon img2 = new ImageIcon("Images/adalaj.jpg");
        label.setIcon(img2);
        label.setBounds(150, 255, 117, 110);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("New label");
        ImageIcon img3 = new ImageIcon("Images/kankaria.jpg");
        label_1.setIcon(img3);
        label_1.setBounds(150, 390, 117, 110);
        getContentPane().add(label_1);
        
        JLabel label_2 = new JLabel("New label");
        ImageIcon img4 = new ImageIcon("Images/sardar.jpg");
        label_2.setIcon(img4);
        label_2.setBounds(150, 543, 117, 110);
        getContentPane().add(label_2);
        
        JLabel lblNewLabel_1 = new JLabel("<html>Sabarmati Ashram <br>\r\n<br>\r\nThis was one of the many residences of Mahatma Gandhi who lived at Sabarmati and Sevagram when he was not travelling across India or in prison. He lived in Sabarmati or Wardha for a total of twelve years with his wife Kasturba Gandhi and followers, including Vinoba Bhave. It was from his base here that Gandhi led the Dandi march also known as the Salt Satyagraha on 12 March 1930.\r\n</html>\r\n");
        lblNewLabel_1.setBounds(332, 68, 417, 160);
        getContentPane().add(lblNewLabel_1);


        
        ba.addActionListener(this);

    }


}